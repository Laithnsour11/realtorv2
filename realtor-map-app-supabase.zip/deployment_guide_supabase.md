# Deal Flow Realtor Database - Deployment Guide (Supabase Version)

## Overview

This document provides instructions for deploying the Deal Flow Realtor Database webapp, which allows CRM users to share and access realtor profiles for novation and wholesaling deals. The application features a Mapbox-based map visualization, search functionality, and collaborative features for sharing realtor information.

## Application Structure

The application is built using:
- **Backend**: Supabase for database and API functionality
- **Frontend**: HTML, CSS, JavaScript with Mapbox GL JS for map visualization
- **Authentication**: Relies on Go High Level's authentication

## Configuration

### Mapbox API Key

The application uses Mapbox for map visualization. The following Mapbox API key has been configured:
```
pk.eyJ1IjoibGFpdGhuc291ciIsImEiOiJjbWE2eW94azEwdHozMmxxNHFlNnlzeGozIn0.21M92anEDO5E4HYxKyAp9w
```

### Supabase Configuration

The application is configured to use Supabase with the following credentials:
- **URL**: `https://btnfyqrltbugnghqrrau.supabase.co`
- **API Key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ0bmZ5cXJsdGJ1Z25naHFycmF1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDczMzE5OTUsImV4cCI6MjA2MjkwNzk5NX0.LZPicqhvUVy9K5obZnkmysk-ou9wZ1RpofFmY-f_73A`

## Supabase Database Setup

Before using the application, you need to set up the following tables in your Supabase project:

### 1. Realtors Table

```sql
CREATE TABLE realtors (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  location TEXT NOT NULL,
  latitude FLOAT NOT NULL,
  longitude FLOAT NOT NULL,
  radius INTEGER NOT NULL DEFAULT 25,
  zillow TEXT,
  realtor_com TEXT,
  website TEXT,
  specialties TEXT,
  deals INTEGER DEFAULT 0,
  notes TEXT,
  submitter TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable full-text search on location field
CREATE INDEX realtors_location_idx ON realtors USING GIN (to_tsvector('english', location));
```

### 2. Comments Table

```sql
CREATE TABLE comments (
  id SERIAL PRIMARY KEY,
  realtor_id INTEGER REFERENCES realtors(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  author TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 3. Edit Requests Table

```sql
CREATE TABLE edit_requests (
  id SERIAL PRIMARY KEY,
  realtor_id INTEGER REFERENCES realtors(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  submitter TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## Deployment Options

### Option 1: Embed in Go High Level Custom Menu Link (Recommended)

Since the primary use case is embedding within Go High Level as a custom menu link, follow these steps:

1. Deploy the static files to a web hosting service (see options below)
2. In Go High Level, navigate to Settings > Custom Menu Links
3. Add a new Custom Menu Link with the following settings:
   - Name: "Deal Flow Realtor Database"
   - URL: Your deployed application URL
   - Icon: Choose an appropriate icon (e.g., map or database)
   - Open in: "iframe" (recommended for seamless integration)

### Option 2: Static Web Hosting

You can deploy the static files to any web hosting service:

1. **GitHub Pages**:
   - Create a new GitHub repository
   - Upload the static files (HTML, CSS, JS)
   - Enable GitHub Pages in the repository settings

2. **Netlify**:
   - Create a new site from the Netlify dashboard
   - Drag and drop the static files folder
   - Netlify will automatically deploy the site

3. **Vercel**:
   - Install Vercel CLI: `npm i -g vercel`
   - Navigate to the static files directory
   - Run `vercel` and follow the prompts

### Option 3: Local Development Server

For testing or development purposes:

1. Install a simple HTTP server:
   ```
   npm install -g http-server
   ```

2. Navigate to the directory containing the static files:
   ```
   cd /path/to/static/files
   ```

3. Start the server:
   ```
   http-server -p 8080
   ```

4. Access the application at `http://localhost:8080`

## Customization

### Branding

To customize the branding:

1. Update the logo and title in `index.html`
2. Modify the color scheme in `css/styles.css` by changing the CSS variables in the `:root` selector

### Features

To add or modify features:

1. Update the HTML structure in `index.html`
2. Modify the styles in `css/styles.css` and `css/additional.css`
3. Update the JavaScript logic in `js/app.js`

## Security Considerations

For production deployment:

1. Consider implementing proper authentication if needed (currently relies on Go High Level's authentication)
2. Set up HTTPS using a valid SSL certificate
3. Configure proper CORS settings if accessing the API from different domains
4. Implement rate limiting for API endpoints
5. Review Supabase Row Level Security (RLS) policies to ensure proper data access control

## Maintenance

For ongoing maintenance:

1. Regularly back up the Supabase database
2. Monitor Supabase logs for errors
3. Update dependencies to address security vulnerabilities
4. Consider implementing analytics to track usage patterns

## Troubleshooting

Common issues and solutions:

- **Map not loading**: Check that the Mapbox API key is valid and has the correct permissions
- **Data not saving to Supabase**: Verify Supabase credentials and table structure
- **CORS errors**: Configure proper CORS headers if accessing the API from different domains

## Support

For additional support or custom development needs, please contact your developer or IT team.
